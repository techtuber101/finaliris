# Utility modules for MCP tool handling
